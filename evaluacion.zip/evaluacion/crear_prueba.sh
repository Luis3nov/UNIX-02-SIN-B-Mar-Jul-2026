#!/usr/bin/env bash
# =============================================================================
#  crear_prueba.sh  —  Generador de evaluación práctica UNIX
#  Autor: Ing. Jonathan E. Tito O. MSc. (Computer Science School)
#
#  Uso:
#      ./crear_prueba.sh <variante>
#      variantes disponibles: orion | kepler | andromeda
#
#  Este script deja un "estado roto" en el directorio actual para que el
#  estudiante lo corrija. También escribe un archivo oculto con el estado
#  inicial (.estado_inicial.conf) que usa calificar.sh para detectar
#  intentos fallidos.
#
#  PRE-REQUISITOS:
#      - bash, coreutils, gnupg
#      - permiso de escritura en /tmp
#      - opcional: git (para el workflow del estudiante)
# =============================================================================

set -u  # intencionalmente NO uso -e: algunas operaciones pueden fallar
        # de manera esperada y el script las maneja explícitamente.

# ---------- Colores ---------------------------------------------------------
RED=$'\033[0;31m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[1;33m'
BLUE=$'\033[0;34m'; BOLD=$'\033[1m'; NC=$'\033[0m'

# ---------- Argumentos ------------------------------------------------------
VARIANTE="${1:-}"

if [[ -z "$VARIANTE" ]]; then
    echo "${RED}ERROR:${NC} debes indicar una variante."
    echo "Uso: $0 <orion|kepler|andromeda>"
    exit 1
fi

# ---------- Configuración por variante --------------------------------------
# Cada variante usa distintos nombres para evitar copia entre cursos.
# Las rúbricas son idénticas; solo cambian los identificadores.
case "$VARIANTE" in
    orion)
        PROYECTO="orion"
        USUARIO_GPG="lyra"
        EMAIL_GPG="lyra@orion.lab"
        DIR_MAL_NOMBRE="notas"          # debería llamarse:
        DIR_NOMBRE_OK="apuntes"
        DIR_FALTANTE="respaldos"
        ARCHIVO_LOG="telemetria.log"
        ARCHIVO_CONF_MAL="config.tmp"   # extensión incorrecta
        ARCHIVO_CONF_OK="config.conf"
        SCRIPT_SH="script.sh"
        ZONA_TMP="/tmp/orion_zone"
        PERMS_P3="640"
        ;;
    kepler)
        PROYECTO="kepler"
        USUARIO_GPG="vega"
        EMAIL_GPG="vega@kepler.lab"
        DIR_MAL_NOMBRE="docs"
        DIR_NOMBRE_OK="registros"
        DIR_FALTANTE="plantillas"
        ARCHIVO_LOG="sensores.log"
        ARCHIVO_CONF_MAL="ajustes.old"
        ARCHIVO_CONF_OK="ajustes.conf"
        SCRIPT_SH="runner.sh"
        ZONA_TMP="/tmp/kepler_zone"
        PERMS_P3="600"
        ;;
    andromeda)
        PROYECTO="andromeda"
        USUARIO_GPG="sirius"
        EMAIL_GPG="sirius@andromeda.lab"
        DIR_MAL_NOMBRE="logs"
        DIR_NOMBRE_OK="diarios"
        DIR_FALTANTE="archivados"
        ARCHIVO_LOG="datos.log"
        ARCHIVO_CONF_MAL="parametros.bak"
        ARCHIVO_CONF_OK="parametros.conf"
        SCRIPT_SH="init.sh"
        ZONA_TMP="/tmp/andromeda_zone"
        PERMS_P3="644"
        ;;
    *)
        echo "${RED}ERROR:${NC} variante desconocida '$VARIANTE'."
        echo "Variantes válidas: orion | kepler | andromeda"
        exit 1
        ;;
esac

echo "${BOLD}${BLUE}=================================================================${NC}"
echo "${BOLD}${BLUE}  GENERANDO EVALUACIÓN PRÁCTICA — variante: ${VARIANTE}${NC}"
echo "${BOLD}${BLUE}=================================================================${NC}"
echo ""

# ---------- Limpieza de estado previo ---------------------------------------
echo "${YELLOW}[1/9]${NC} Limpiando estado previo..."
rm -rf "./${PROYECTO}" 2>/dev/null
rm -f  "./.estado_inicial_${VARIANTE}.conf" 2>/dev/null
rm -rf "${ZONA_TMP}" 2>/dev/null

# ---------- Problema 1: Estructura de directorios rota ----------------------
echo "${YELLOW}[2/9]${NC} Problema 1: creando estructura de directorios con 2 fallos..."

mkdir -p "./${PROYECTO}/${DIR_MAL_NOMBRE}"   # fallo 1a: nombre incorrecto
# NO creamos ${DIR_FALTANTE}              <- fallo 1b: directorio faltante

# Contenido que debe moverse CON el directorio al renombrarlo
cat > "./${PROYECTO}/${DIR_MAL_NOMBRE}/README.txt" <<EOF
Este archivo fue creado por el generador del examen.
Al renombrar el directorio, este contenido debe viajar con él
(usar 'mv', no 'rm'+'mkdir').
EOF

# ---------- Problema 2: Archivos mal ubicados/nombrados ---------------------
echo "${YELLOW}[3/9]${NC} Problema 2: creando archivos mal ubicados/nombrados..."

# Fallo 2a: archivo de log en la RAÍZ del proyecto en vez de dentro del dir
cat > "./${PROYECTO}/${ARCHIVO_LOG}" <<EOF
2026-04-22T08:00:00Z sensor=temperatura valor=21.3 C
2026-04-22T08:05:00Z sensor=presion    valor=1013.2 hPa
2026-04-22T08:10:00Z sensor=humedad    valor=67.5 %
2026-04-22T08:15:00Z sensor=temperatura valor=21.5 C
2026-04-22T08:20:00Z sensor=presion    valor=1013.4 hPa
EOF

# Fallo 2b: archivo de configuración con extensión incorrecta
cat > "./${PROYECTO}/${ARCHIVO_CONF_MAL}" <<EOF
# Configuración del módulo (archivo con extensión incorrecta)
host=estacion-alpha
port=9200
interval=5s
log_level=INFO
EOF

# ---------- Problema 3: permisos numéricos (archivo con perms muy abiertos) -
echo "${YELLOW}[4/9]${NC} Problema 3: permisos numéricos — aplicando 666 inicial..."
chmod 666 "./${PROYECTO}/${ARCHIVO_LOG}"
PERMS_INICIAL_P3=$(stat -c "%a" "./${PROYECTO}/${ARCHIVO_LOG}")

# ---------- Problema 4: permisos simbólicos --------------------------------
echo "${YELLOW}[5/9]${NC} Problema 4: script ejecutable y config para permisos simbólicos..."

cat > "./${PROYECTO}/${SCRIPT_SH}" <<'EOF'
#!/usr/bin/env bash
# Script que el estudiante debe dejar ejecutable por su dueño.
echo "[$(date -Iseconds)] ejecución OK"
EOF

# Fallo 4a: script SIN bit x para el dueño (644)
chmod 644 "./${PROYECTO}/${SCRIPT_SH}"
PERMS_INICIAL_P4A=$(stat -c "%a" "./${PROYECTO}/${SCRIPT_SH}")

# Fallo 4b: archivo de configuración con permiso de escritura para others (666)
chmod 666 "./${PROYECTO}/${ARCHIVO_CONF_MAL}"
PERMS_INICIAL_P4B=$(stat -c "%a" "./${PROYECTO}/${ARCHIVO_CONF_MAL}")

# ---------- Problema 5: SUID (inicialmente apagado) -------------------------
echo "${YELLOW}[6/9]${NC} Problema 5: SUID apagado (estado inicial)..."
# SUID ya está apagado porque el chmod anterior no lo activó.
SUID_INICIAL=$(stat -c "%a" "./${PROYECTO}/${SCRIPT_SH}" | awk '{ if(length($0)==4) print substr($0,1,1); else print "0" }')

# ---------- Problema 6: sticky bit (inicialmente apagado) -------------------
echo "${YELLOW}[7/9]${NC} Problema 6: creando ${ZONA_TMP} SIN sticky bit..."
mkdir -p "${ZONA_TMP}"
chmod 777 "${ZONA_TMP}"   # drwxrwxrwx — permisivo pero SIN sticky (falta la 't')
STICKY_INICIAL=$(stat -c "%a" "${ZONA_TMP}" | awk '{ if(length($0)==4) print substr($0,1,1); else print "0" }')

# ---------- Problema 8 (preparación): firma detached corrompida -------------
echo "${YELLOW}[8/9]${NC} Problema 8: preparando firma corrupta del instructor..."

# Creamos una llave temporal del "instructor" para firmar y luego corromper.
# Dejamos la llave pública en el llavero para que 'gpg --verify' reporte
# "BAD signature" (y no "No public key").
INSTRUCTOR_EMAIL="instructor-${VARIANTE}@unix.eval"
INSTRUCTOR_NAME="Instructor-${VARIANTE}"

# Asegurar que gpg-agent esté disponible
if ! command -v gpg >/dev/null 2>&1; then
    echo "${RED}ERROR:${NC} gpg no está instalado. Ejecuta: sudo apt install -y gnupg"
    exit 1
fi

# Generar llave del instructor en modo batch (sin passphrase)
INSTRUCTOR_BATCH=$(mktemp)
cat > "$INSTRUCTOR_BATCH" <<EOF
%no-protection
Key-Type: RSA
Key-Length: 2048
Name-Real: ${INSTRUCTOR_NAME}
Name-Email: ${INSTRUCTOR_EMAIL}
Expire-Date: 0
%commit
EOF

gpg --batch --generate-key "$INSTRUCTOR_BATCH" >/dev/null 2>&1
rm -f "$INSTRUCTOR_BATCH"

# Firmar el script con la llave del instructor (detached, binario)
gpg --batch --yes --pinentry-mode loopback \
    --local-user "$INSTRUCTOR_EMAIL" \
    --detach-sign \
    --output "./${PROYECTO}/${SCRIPT_SH}.sig" \
    "./${PROYECTO}/${SCRIPT_SH}" 2>/dev/null

# Corromper la firma: sobrescribir algunos bytes en el medio del archivo.
SIG_FILE="./${PROYECTO}/${SCRIPT_SH}.sig"
if [[ -f "$SIG_FILE" ]]; then
    SIG_SIZE=$(stat -c "%s" "$SIG_FILE")
    # Escribir 8 bytes aleatorios en el medio del archivo (preserva longitud)
    MITAD=$(( SIG_SIZE / 2 ))
    dd if=/dev/urandom of="$SIG_FILE" bs=1 count=8 seek="$MITAD" conv=notrunc 2>/dev/null
    echo "      ✓ ${SCRIPT_SH}.sig generado y corrompido (${SIG_SIZE} bytes)"
else
    echo "${RED}      ⚠ No se pudo generar la firma del instructor${NC}"
fi

# Guardamos el hash del .sig corrupto para detectar si el estudiante lo
# sobrescribió (intento) o lo dejó intacto (sin respuesta).
SIG_HASH_INICIAL=$(sha256sum "$SIG_FILE" 2>/dev/null | awk '{print $1}')

# ---------- Inicializar repositorio git (workflow del estudiante) ----------
echo "${YELLOW}[9/9]${NC} Inicializando repositorio git para el workflow..."
if command -v git >/dev/null 2>&1; then
    if [[ ! -d .git ]]; then
        git init -q 2>/dev/null
        # Config mínima por si no está global
        git config user.email "estudiante@examen.local" 2>/dev/null
        git config user.name  "Estudiante" 2>/dev/null
    fi
    git add . 2>/dev/null
    git commit -q -m "Estado inicial del examen (variante: ${VARIANTE})" --allow-empty 2>/dev/null
    echo "      ✓ repo git inicializado con commit base"
else
    echo "      ⚠ git no disponible — el estudiante no podrá seguir el workflow de commits"
fi

# ---------- Guardar estado inicial para calificar.sh ------------------------
ESTADO_FILE="./.estado_inicial_${VARIANTE}.conf"
cat > "$ESTADO_FILE" <<EOF
# Estado inicial del examen — generado por crear_prueba.sh
# NO EDITAR ESTE ARCHIVO. calificar.sh lo necesita para detectar intentos.
VARIANTE="${VARIANTE}"
PROYECTO="${PROYECTO}"
USUARIO_GPG="${USUARIO_GPG}"
EMAIL_GPG="${EMAIL_GPG}"
DIR_MAL_NOMBRE="${DIR_MAL_NOMBRE}"
DIR_NOMBRE_OK="${DIR_NOMBRE_OK}"
DIR_FALTANTE="${DIR_FALTANTE}"
ARCHIVO_LOG="${ARCHIVO_LOG}"
ARCHIVO_CONF_MAL="${ARCHIVO_CONF_MAL}"
ARCHIVO_CONF_OK="${ARCHIVO_CONF_OK}"
SCRIPT_SH="${SCRIPT_SH}"
ZONA_TMP="${ZONA_TMP}"
PERMS_P3_TARGET="${PERMS_P3}"
PERMS_INICIAL_P3="${PERMS_INICIAL_P3}"
PERMS_INICIAL_P4A="${PERMS_INICIAL_P4A}"
PERMS_INICIAL_P4B="${PERMS_INICIAL_P4B}"
SUID_INICIAL="${SUID_INICIAL}"
STICKY_INICIAL="${STICKY_INICIAL}"
SIG_HASH_INICIAL="${SIG_HASH_INICIAL}"
INSTRUCTOR_EMAIL="${INSTRUCTOR_EMAIL}"
EOF

# Añadir al .gitignore para que el estado no se commiteé accidentalmente
if [[ ! -f .gitignore ]]; then
    echo "${ESTADO_FILE#./}" > .gitignore
else
    grep -q "^${ESTADO_FILE#./}\$" .gitignore 2>/dev/null || echo "${ESTADO_FILE#./}" >> .gitignore
fi

# ---------- Generar ENUNCIADO.md personalizado -----------------------------
# Buscamos la plantilla en la misma carpeta que este script.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLANTILLA="${SCRIPT_DIR}/ENUNCIADO.md.tpl"
if [[ -f "$PLANTILLA" ]]; then
    sed \
        -e "s|{{VARIANTE}}|${VARIANTE}|g" \
        -e "s|{{PROYECTO}}|${PROYECTO}|g" \
        -e "s|{{USUARIO_GPG}}|${USUARIO_GPG}|g" \
        -e "s|{{EMAIL_GPG}}|${EMAIL_GPG}|g" \
        -e "s|{{DIR_MAL_NOMBRE}}|${DIR_MAL_NOMBRE}|g" \
        -e "s|{{DIR_NOMBRE_OK}}|${DIR_NOMBRE_OK}|g" \
        -e "s|{{DIR_FALTANTE}}|${DIR_FALTANTE}|g" \
        -e "s|{{ARCHIVO_LOG}}|${ARCHIVO_LOG}|g" \
        -e "s|{{ARCHIVO_CONF_MAL}}|${ARCHIVO_CONF_MAL}|g" \
        -e "s|{{ARCHIVO_CONF_OK}}|${ARCHIVO_CONF_OK}|g" \
        -e "s|{{SCRIPT_SH}}|${SCRIPT_SH}|g" \
        -e "s|{{ZONA_TMP}}|${ZONA_TMP}|g" \
        -e "s|{{PERMS_P3}}|${PERMS_P3}|g" \
        "$PLANTILLA" > ./ENUNCIADO.md
    echo "      ✓ ENUNCIADO.md generado para la variante ${VARIANTE}"
else
    echo "      ⚠ No se encontró ENUNCIADO.md.tpl junto al script; enunciado no generado"
fi

# ---------- Resumen final ---------------------------------------------------
echo ""
echo "${BOLD}${GREEN}=================================================================${NC}"
echo "${BOLD}${GREEN}  EVALUACIÓN LISTA — variante: ${VARIANTE}${NC}"
echo "${BOLD}${GREEN}=================================================================${NC}"
echo ""
echo "${BOLD}Datos para el estudiante:${NC}"
echo "  Proyecto:         ${PROYECTO}/"
echo "  Usuario GPG:      ${USUARIO_GPG}"
echo "  Email GPG:        ${EMAIL_GPG}"
echo "  Zona compartida:  ${ZONA_TMP}"
echo ""
echo "${BOLD}Archivo de estado inicial:${NC}  ${ESTADO_FILE}"
echo ""
echo "${BOLD}Para calificar:${NC}"
echo "  ./calificar.sh ${VARIANTE}"
echo ""
echo "${BOLD}${YELLOW}Contenido generado:${NC}"
ls -la "./${PROYECTO}/" 2>/dev/null | sed 's/^/  /'
echo ""
ls -la "./${PROYECTO}/${DIR_MAL_NOMBRE}/" 2>/dev/null | sed 's/^/  /'
echo ""
echo "${BOLD}${YELLOW}Zona temporal:${NC}"
ls -ld "${ZONA_TMP}" 2>/dev/null | sed 's/^/  /'
echo ""
